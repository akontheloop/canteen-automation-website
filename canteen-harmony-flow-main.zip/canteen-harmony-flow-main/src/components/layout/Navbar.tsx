
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  ShoppingCart, 
  LogOut, 
  User, 
  Home, 
  Menu as MenuIcon, 
  X, 
  BookOpenText,
  MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/hooks/use-cart';
import { toast } from 'sonner';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { cartItems } = useCart();
  const [user, setUser] = useState<{email: string, isAdmin: boolean} | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('canteen-user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('canteen-user');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const navLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: <Home className="w-5 h-5" /> },
    { name: 'Menu', path: '/menu', icon: <MenuIcon className="w-5 h-5" /> },
    { name: 'Reviews', path: '/reviews', icon: <BookOpenText className="w-5 h-5" /> },
    { name: 'Chatbot', path: '/chatbot', icon: <MessageCircle className="w-5 h-5" /> },
    { name: 'Profile', path: '/profile', icon: <User className="w-5 h-5" /> },
  ];

  if (user?.isAdmin) {
    navLinks.push({ name: 'Admin', path: '/admin', icon: <User className="w-5 h-5" /> });
  }

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur-lg bg-white/80 border-b border-gray-200">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/dashboard" className="flex items-center space-x-2">
          <div className="font-bold text-xl">
            <span className="text-canteen-blue">Canteen</span>
            <span className="text-canteen-red">Hub</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`flex items-center space-x-1 px-3 py-2 rounded-md transition-colors ${
                isActive(link.path)
                  ? "bg-canteen-blue/10 text-canteen-blue"
                  : "text-gray-600 hover:text-canteen-blue hover:bg-canteen-blue/5"
              }`}
            >
              {link.icon}
              <span>{link.name}</span>
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          {user && (
            <>
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative" 
                onClick={() => navigate('/cart')}
              >
                <ShoppingCart className="w-5 h-5" />
                {cartItems.length > 0 && (
                  <Badge 
                    className="absolute -top-2 -right-2 bg-canteen-red"
                  >
                    {cartItems.length}
                  </Badge>
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-canteen-red"
              >
                <LogOut className="w-5 h-5 mr-1" />
                Logout
              </Button>
            </>
          )}
        </div>

        {/* Mobile Navigation */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <MenuIcon className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[80%] sm:w-[350px]">
            <nav className="flex flex-col space-y-4 mt-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-lg transition-colors ${
                    isActive(link.path)
                      ? "bg-canteen-blue/10 text-canteen-blue"
                      : "text-gray-600 hover:text-canteen-blue hover:bg-canteen-blue/5"
                  }`}
                >
                  {link.icon}
                  <span>{link.name}</span>
                </Link>
              ))}
              
              {user && (
                <>
                  <Link
                    to="/cart"
                    className="flex items-center space-x-2 px-4 py-3 rounded-lg text-gray-600 hover:text-canteen-blue hover:bg-canteen-blue/5"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    <span>Cart</span>
                    {cartItems.length > 0 && (
                      <Badge className="bg-canteen-red ml-auto">{cartItems.length}</Badge>
                    )}
                  </Link>
                  
                  <Button 
                    variant="ghost" 
                    onClick={handleLogout}
                    className="justify-start px-4 py-3 h-auto text-gray-600 hover:text-canteen-red hover:bg-canteen-red/5"
                  >
                    <LogOut className="w-5 h-5 mr-2" />
                    Logout
                  </Button>
                </>
              )}
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};

export default Navbar;
