
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold">
              <span className="text-canteen-blue">Canteen</span>
              <span className="text-canteen-red">Hub</span>
            </h3>
            <p className="text-gray-400">
              Streamlining canteen management with delicious meals and excellent service.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/dashboard" className="text-gray-400 hover:text-canteen-blue transition-colors">Home</Link></li>
              <li><Link to="/menu" className="text-gray-400 hover:text-canteen-blue transition-colors">Menu</Link></li>
              <li><Link to="/reviews" className="text-gray-400 hover:text-canteen-blue transition-colors">Reviews</Link></li>
              <li><Link to="/cart" className="text-gray-400 hover:text-canteen-blue transition-colors">Cart</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-400">
              <li>123 Canteen Street</li>
              <li>Food City, FC 12345</li>
              <li>contact@canteenhub.com</li>
              <li>(123) 456-7890</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Opening Hours</h4>
            <ul className="space-y-2 text-gray-400">
              <li>Monday - Friday: 8:00 AM - 6:00 PM</li>
              <li>Saturday: 9:00 AM - 5:00 PM</li>
              <li>Sunday: Closed</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400">© 2025 CanteenHub. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-canteen-blue transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-canteen-blue transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
