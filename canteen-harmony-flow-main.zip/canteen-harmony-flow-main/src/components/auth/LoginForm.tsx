
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { LogIn, Mail, Phone } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const { signIn, isSupabaseConfigured } = useAuth();

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (mode === 'register') {
        if (!isSupabaseConfigured) {
          toast.error('Registration requires Supabase configuration. Using demo login instead.');
          await signIn(email, password);
        } else {
          // Registration code using Supabase
          const { error } = await signIn(email, password);
          if (error) throw error;
          toast.success('Registration successful! Please check your email for verification.');
        }
      } else {
        await signIn(email, password);
      }
    } catch (error: any) {
      toast.error(error.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhoneAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!isSupabaseConfigured) {
        toast.warning('Phone authentication requires Supabase configuration. Please enter an email instead.');
      } else {
        // Phone authentication code using Supabase
        toast.success('OTP sent to your phone number!');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto animate-fade-in">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">
          <span className="gradient-text">Canteen Management</span>
        </CardTitle>
        <CardDescription className="text-center">
          {mode === 'login' ? 'Welcome back!' : 'Create your account'}
          {!isSupabaseConfigured && (
            <p className="mt-2 text-yellow-600 text-sm">
              Running in demo mode. Use any email/password to log in.
            </p>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="email" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="email">
              <Mail className="w-4 h-4 mr-2" />
              Email
            </TabsTrigger>
            <TabsTrigger value="phone">
              <Phone className="w-4 h-4 mr-2" />
              Phone
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="email">
            <form onSubmit={handleEmailAuth} className="space-y-4">
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="canteen-input"
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="canteen-input"
              />
              <Button 
                type="submit"
                className="w-full canteen-btn-primary" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center justify-center">
                    <span className="animate-spin mr-2">●</span> 
                    {mode === 'login' ? 'Logging in...' : 'Registering...'}
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    <LogIn className="w-4 h-4 mr-2" />
                    {mode === 'login' ? 'Sign In' : 'Register'}
                  </span>
                )}
              </Button>
            </form>
          </TabsContent>
          
          <TabsContent value="phone">
            <form onSubmit={handlePhoneAuth} className="space-y-4">
              <Input
                type="tel"
                placeholder="Phone Number (with country code)"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="canteen-input"
              />
              <Button 
                type="submit"
                className="w-full canteen-btn-primary" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center justify-center">
                    <span className="animate-spin mr-2">●</span> 
                    Sending OTP...
                  </span>
                ) : (
                  <span className="flex items-center justify-center">
                    <Phone className="w-4 h-4 mr-2" />
                    Send OTP
                  </span>
                )}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <Button
          variant="link"
          className="text-sm text-gray-500"
          onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
        >
          {mode === 'login' 
            ? "Don't have an account? Register" 
            : "Already have an account? Login"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default LoginForm;
