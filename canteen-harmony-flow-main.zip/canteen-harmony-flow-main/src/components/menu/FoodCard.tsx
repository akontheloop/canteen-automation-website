
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, ShoppingCart } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import { toast } from 'sonner';

export interface FoodItem {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPopular?: boolean;
}

interface FoodCardProps {
  item: FoodItem;
}

const FoodCard: React.FC<FoodCardProps> = ({ item }) => {
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(item);
    toast.success(`${item.name} added to cart!`);
  };

  return (
    <Card className="canteen-card overflow-hidden h-full flex flex-col animate-fade-in group">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={item.image} 
          alt={item.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
        />
        {item.isPopular && (
          <div className="absolute top-2 right-2 bg-canteen-red text-white text-xs font-bold px-2 py-1 rounded-full">
            Popular
          </div>
        )}
        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/50 to-transparent p-2">
          <span className="text-white font-bold text-xl">${item.price.toFixed(2)}</span>
        </div>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">{item.name}</CardTitle>
        <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-full inline-block">
          {item.category}
        </span>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-gray-600 text-sm line-clamp-2">{item.description}</p>
      </CardContent>
      <CardFooter className="pt-0">
        <Button 
          onClick={handleAddToCart} 
          className="w-full canteen-btn-primary group"
        >
          <span className="flex items-center justify-center">
            <ShoppingCart className="w-4 h-4 mr-2 group-hover:animate-bounce" />
            Add to Cart
          </span>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default FoodCard;
