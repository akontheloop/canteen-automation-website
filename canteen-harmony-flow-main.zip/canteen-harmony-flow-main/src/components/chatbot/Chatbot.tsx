
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { MessageCircle, Send, X } from 'lucide-react';
import { toast } from 'sonner';

interface Message {
  id: number;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const botResponses: Record<string, string[]> = {
  menu: [
    "Our menu includes daily specials, vegetarian options, and different international cuisines each day.",
    "You can view the full menu in the Menu section. We update it weekly!"
  ],
  order: [
    "To place an order, browse our menu and click 'Add to Cart' for items you want.",
    "You can review your cart and checkout when ready."
  ],
  payment: [
    "We accept credit/debit cards, mobile payments, and cash.",
    "You can also set up meal plans and prepaid accounts."
  ],
  hours: [
    "The canteen is open Monday-Friday from 8:00 AM to 6:00 PM, Saturday from 9:00 AM to 5:00 PM, and closed on Sundays."
  ],
  specials: [
    "Today's specials include Taco Tuesday options and our Chef's special soup!",
    "Check the 'Popular' tag on menu items for our most-loved dishes."
  ],
  vegetarian: [
    "Yes, we always have vegetarian and vegan options available.",
    "Look for the vegetarian tag on menu items."
  ],
  gluten: [
    "We offer gluten-free options. Please check with our staff for today's gluten-free menu items."
  ],
  staff: [
    "Our food is prepared by professionally trained chefs focusing on nutrition and taste."
  ],
  feedback: [
    "We value your feedback! Please visit the Reviews section to share your thoughts on our food and service."
  ],
  allergy: [
    "Food allergen information is available for all menu items. Please inform our staff about any food allergies."
  ],
  hi: [
    "Hello! How can I help you with canteen management today?",
    "Hi there! Ask me anything about our canteen services!"
  ],
  hello: [
    "Hello! How can I help you with canteen management today?",
    "Hi there! Ask me anything about our canteen services!"
  ],
  thanks: [
    "You're welcome! Let me know if you need anything else.",
    "Happy to help! Enjoy your meal!"
  ],
  thank: [
    "You're welcome! Let me know if you need anything else.",
    "Happy to help! Enjoy your meal!"
  ]
};

const defaultResponse = [
  "I don't have specific information on that topic. Can I help with menu options, ordering, payment methods, or hours of operation?",
  "I'm not sure about that. Would you like to know about our menu, ordering process, or payment options instead?"
];

const Chatbot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content: "Hello! I'm your CanteenHub assistant. How can I help you today?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      content: input,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = getBotResponse(input);
      const botMessage: Message = {
        id: messages.length + 2,
        content: botResponse,
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const getBotResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    // Check for keyword matches
    for (const [keyword, responses] of Object.entries(botResponses)) {
      if (lowerInput.includes(keyword)) {
        return responses[Math.floor(Math.random() * responses.length)];
      }
    }
    
    // Default response if no keywords match
    return defaultResponse[Math.floor(Math.random() * defaultResponse.length)];
  };

  const toggleChatbot = () => {
    setIsOpen(prev => !prev);
  };

  return (
    <>
      {/* Floating button */}
      {!isOpen && (
        <Button 
          onClick={toggleChatbot}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-canteen-blue hover:bg-canteen-blue-dark shadow-lg z-50 flex items-center justify-center p-0"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}

      {/* Chatbot window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-[320px] sm:w-[350px] h-[500px] shadow-2xl z-50 flex flex-col animate-fade-in">
          <CardHeader className="p-4 bg-canteen-blue text-white rounded-t-xl flex flex-row justify-between items-center">
            <CardTitle className="text-lg font-semibold">CanteenHub Assistant</CardTitle>
            <Button 
              size="icon" 
              variant="ghost" 
              onClick={toggleChatbot} 
              className="h-8 w-8 rounded-full text-white hover:bg-canteen-blue-dark"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="flex-grow overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === 'user' 
                      ? 'bg-canteen-blue text-white rounded-tr-none' 
                      : 'bg-gray-100 text-gray-800 rounded-tl-none'
                  } animate-slide-in`}
                >
                  <p>{message.content}</p>
                  <span className="text-xs opacity-70 mt-1 block">
                    {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </CardContent>
          <CardFooter className="p-3 border-t">
            <form onSubmit={handleSendMessage} className="flex w-full">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="flex-grow mr-2 canteen-input"
              />
              <Button 
                type="submit" 
                size="icon" 
                className="bg-canteen-blue hover:bg-canteen-blue-dark"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}
    </>
  );
};

export default Chatbot;
