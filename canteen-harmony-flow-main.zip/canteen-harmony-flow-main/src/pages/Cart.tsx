
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Trash, Plus, Minus, ShoppingCart, ArrowRight } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import Layout from '@/components/layout/Layout';
import { toast } from 'sonner';

const Cart = () => {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart();
  const [isLoading, setIsLoading] = useState(true);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const user = localStorage.getItem('canteen-user');
    if (!user) {
      navigate('/login');
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast.error('Your cart is empty');
      return;
    }

    setIsCheckingOut(true);
    
    // Simulate checkout process
    setTimeout(() => {
      toast.success('Order placed successfully!');
      clearCart();
      setIsCheckingOut(false);
      navigate('/dashboard');
    }, 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Your <span className="gradient-text">Cart</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Review your order and proceed to checkout.
        </p>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items */}
          <div className="w-full lg:w-2/3 animate-fade-in delay-200">
            {cartItems.length === 0 ? (
              <Card className="canteen-card">
                <CardContent className="pt-6 text-center">
                  <ShoppingCart className="mx-auto h-16 w-16 text-gray-300 mb-4" />
                  <h2 className="text-2xl font-semibold text-gray-600 mb-2">Your cart is empty</h2>
                  <p className="text-gray-500 mb-4">Add some delicious items to your cart.</p>
                  <Button 
                    className="canteen-btn-primary" 
                    onClick={() => navigate('/menu')}
                  >
                    Browse Menu
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item, index) => (
                  <Card key={item.id} className="canteen-card animate-fade-in" style={{ animationDelay: `${(index + 3) * 100}ms` }}>
                    <CardContent className="p-4">
                      <div className="flex flex-col sm:flex-row items-center">
                        <div className="w-full sm:w-24 h-24 rounded-md overflow-hidden mr-0 sm:mr-4 mb-4 sm:mb-0">
                          <img 
                            src={item.image} 
                            alt={item.name} 
                            className="w-full h-full object-cover" 
                          />
                        </div>
                        <div className="flex-grow">
                          <h3 className="font-semibold text-lg">{item.name}</h3>
                          <p className="text-gray-500 text-sm mb-2">{item.category}</p>
                          <p className="font-medium text-canteen-blue">${(item.price * item.quantity).toFixed(2)}</p>
                        </div>
                        
                        <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                          <div className="flex items-center border rounded-md">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-gray-500"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-gray-500"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                          
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-canteen-red hover:bg-canteen-red/10"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    className="text-canteen-red border-canteen-red hover:bg-canteen-red/10"
                    onClick={() => {
                      if (confirm('Are you sure you want to clear your cart?')) {
                        clearCart();
                        toast.success('Cart cleared');
                      }
                    }}
                  >
                    <Trash className="h-4 w-4 mr-2" />
                    Clear Cart
                  </Button>
                </div>
              </div>
            )}
          </div>
          
          {/* Order Summary */}
          <div className="w-full lg:w-1/3 animate-fade-in delay-400">
            <Card className="canteen-card sticky top-24">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Subtotal */}
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span>${getTotalPrice().toFixed(2)}</span>
                </div>
                
                {/* Tax */}
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax (10%)</span>
                  <span>${(getTotalPrice() * 0.1).toFixed(2)}</span>
                </div>
                
                {/* Delivery Fee */}
                <div className="flex justify-between">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span>$2.00</span>
                </div>
                
                {/* Total */}
                <div className="border-t pt-4 flex justify-between font-semibold">
                  <span>Total</span>
                  <span className="text-canteen-blue text-xl">
                    ${(getTotalPrice() * 1.1 + 2).toFixed(2)}
                  </span>
                </div>
                
                {/* Promo Code */}
                <div className="pt-4">
                  <label className="block text-sm mb-2">Promo Code</label>
                  <div className="flex space-x-2">
                    <Input className="canteen-input" placeholder="Enter code" />
                    <Button variant="outline">Apply</Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  className="canteen-btn-primary w-full" 
                  disabled={cartItems.length === 0 || isCheckingOut}
                  onClick={handleCheckout}
                >
                  {isCheckingOut ? (
                    <span className="flex items-center">
                      <span className="animate-spin mr-2">●</span> Processing...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      Checkout <ArrowRight className="ml-2 h-4 w-4" />
                    </span>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cart;
