
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Mail, Phone, MapPin, Save, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '@/components/layout/Layout';

interface ProfileData {
  email: string;
  name: string;
  phone: string;
  address: string;
}

const Profile = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<{ email: string; isAdmin: boolean } | null>(null);
  const [profileData, setProfileData] = useState<ProfileData>({
    email: '',
    name: '',
    phone: '',
    address: '',
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem('canteen-user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      
      // Set email from stored user
      setProfileData(prev => ({
        ...prev,
        email: parsedUser.email,
      }));
      
      // Load profile data if exists
      const storedProfile = localStorage.getItem('canteen-profile');
      if (storedProfile) {
        try {
          const parsedProfile = JSON.parse(storedProfile);
          setProfileData(prev => ({
            ...prev,
            ...parsedProfile,
          }));
        } catch (e) {
          console.error('Failed to parse profile data', e);
        }
      }
    } else {
      navigate('/login');
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  const handleSaveProfile = () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      localStorage.setItem('canteen-profile', JSON.stringify(profileData));
      toast.success('Profile updated successfully');
      setIsSaving(false);
    }, 1000);
  };

  const handleLogout = () => {
    localStorage.removeItem('canteen-user');
    toast.success('Logged out successfully');
    navigate('/login');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Your <span className="gradient-text">Profile</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Manage your account settings and preferences.
        </p>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Left column - User card */}
          <div className="w-full md:w-1/3 animate-fade-in delay-200">
            <Card className="canteen-card overflow-hidden">
              <div className="h-32 bg-blue-red-gradient"></div>
              <div className="relative px-6">
                <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-white p-2 rounded-full">
                  <div className="w-20 h-20 rounded-full bg-canteen-blue/10 flex items-center justify-center">
                    <User className="w-10 h-10 text-canteen-blue" />
                  </div>
                </div>
                <div className="pt-12 pb-6 text-center">
                  <h2 className="text-xl font-bold">{profileData.name || 'User'}</h2>
                  <p className="text-gray-500">{profileData.email}</p>
                  <p className="text-gray-500 mt-1">{user?.isAdmin ? 'Administrator' : 'Customer'}</p>
                </div>
              </div>
              <CardFooter className="flex justify-center border-t p-4">
                <Button 
                  variant="outline" 
                  className="border-canteen-red text-canteen-red hover:bg-canteen-red/10"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Right column - Profile tabs */}
          <div className="w-full md:w-2/3 animate-fade-in delay-300">
            <Tabs defaultValue="personal" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="personal">Personal Info</TabsTrigger>
                <TabsTrigger value="account">Account</TabsTrigger>
                <TabsTrigger value="preferences">Preferences</TabsTrigger>
              </TabsList>

              <TabsContent value="personal">
                <Card className="canteen-card">
                  <CardHeader>
                    <CardTitle>Personal Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Full Name</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <Input
                          className="pl-10 canteen-input"
                          placeholder="Enter your name"
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Email</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <Input
                          className="pl-10 canteen-input"
                          type="email"
                          value={profileData.email}
                          disabled
                        />
                      </div>
                      <p className="text-xs text-gray-500">Your email cannot be changed</p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Phone Number</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <Input
                          className="pl-10 canteen-input"
                          placeholder="Enter your phone number"
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Address</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-4 transform -translate-y-1/2 text-gray-400" />
                        <textarea
                          className="pl-10 canteen-input min-h-[100px] w-full"
                          placeholder="Enter your address"
                          value={profileData.address}
                          onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="canteen-btn-primary w-full" 
                      onClick={handleSaveProfile}
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <span className="flex items-center">
                          <span className="animate-spin mr-2">●</span> Saving...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </span>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="account">
                <Card className="canteen-card">
                  <CardHeader>
                    <CardTitle>Account Settings</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-500 mb-4">
                      Manage your account settings, password, and notifications.
                    </p>
                    
                    {/* Password Change Form */}
                    <div className="space-y-4 mb-6">
                      <h3 className="font-medium">Change Password</h3>
                      <div>
                        <Input
                          type="password"
                          placeholder="Current Password"
                          className="canteen-input mb-3"
                        />
                      </div>
                      <div>
                        <Input
                          type="password"
                          placeholder="New Password"
                          className="canteen-input mb-3"
                        />
                      </div>
                      <div>
                        <Input
                          type="password"
                          placeholder="Confirm New Password"
                          className="canteen-input"
                        />
                      </div>
                    </div>
                    
                    <Button 
                      className="canteen-btn-primary"
                      onClick={() => toast.info('Password change functionality will be available soon')} 
                    >
                      Update Password
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="preferences">
                <Card className="canteen-card">
                  <CardHeader>
                    <CardTitle>Your Preferences</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-500 mb-6">
                      Customize your experience with personal preferences.
                    </p>
                    
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-2">Dietary Preferences</h3>
                        <div className="grid grid-cols-2 gap-2">
                          {["Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free", "Nut-Free", "Low Carb"].map((pref) => (
                            <label key={pref} className="flex items-center space-x-2 cursor-pointer p-2 border rounded hover:bg-gray-50">
                              <input type="checkbox" className="rounded text-canteen-blue" />
                              <span>{pref}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium mb-2">Notification Preferences</h3>
                        <div className="space-y-3">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="rounded text-canteen-blue" defaultChecked />
                            <span>Order Updates</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="rounded text-canteen-blue" defaultChecked />
                            <span>Special Offers</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" className="rounded text-canteen-blue" defaultChecked />
                            <span>New Menu Items</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="canteen-btn-primary"
                      onClick={() => toast.success('Preferences saved successfully')}
                    >
                      Save Preferences
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
