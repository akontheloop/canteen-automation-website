
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { User, ShoppingCart, BookOpenText, MessageCircle, ArrowRight } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    const user = localStorage.getItem('canteen-user');
    if (user) {
      navigate('/dashboard');
    }
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center animated-bg overflow-hidden">
        <div className="container mx-auto text-center z-10 px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            <span className="gradient-text">CanteenHub</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-700 max-w-2xl mx-auto mb-10 animate-fade-in delay-100">
            The ultimate canteen management system with smooth animations, intelligent chatbot, and easy ordering.
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in delay-200">
            <Button
              className="canteen-btn-primary text-lg py-6 px-8"
              onClick={() => navigate('/login')}
            >
              <User className="mr-2 h-5 w-5" />
              Get Started
            </Button>
          </div>

          {/* Floating Cards */}
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="glassmorphism p-6 rounded-xl animate-float delay-300">
              <ShoppingCart className="h-10 w-10 text-canteen-blue mb-4 mx-auto" />
              <h3 className="text-xl font-bold mb-2">Quick Ordering</h3>
              <p className="text-gray-600">Order food seamlessly with our intuitive interface</p>
            </div>
            
            <div className="glassmorphism p-6 rounded-xl animate-float delay-500">
              <BookOpenText className="h-10 w-10 text-canteen-red mb-4 mx-auto" />
              <h3 className="text-xl font-bold mb-2">Customer Reviews</h3>
              <p className="text-gray-600">Leave feedback and read what others have to say</p>
            </div>
            
            <div className="glassmorphism p-6 rounded-xl animate-float delay-700">
              <MessageCircle className="h-10 w-10 text-green-500 mb-4 mx-auto" />
              <h3 className="text-xl font-bold mb-2">Smart Chatbot</h3>
              <p className="text-gray-600">Get instant answers to all your canteen questions</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
            Powerful <span className="gradient-text">Features</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="bg-white p-8 rounded-2xl shadow-lg transition-transform hover:-translate-y-1 duration-300">
              <div className="w-16 h-16 rounded-full bg-canteen-blue/10 flex items-center justify-center mb-6">
                <User className="h-8 w-8 text-canteen-blue" />
              </div>
              <h3 className="text-xl font-bold mb-3">User Authentication</h3>
              <p className="text-gray-600 mb-4">Secure login system with role-based access control for users and administrators.</p>
              <Button 
                variant="link" 
                className="text-canteen-blue p-0 flex items-center"
                onClick={() => navigate('/login')}
              >
                Try it out <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg transition-transform hover:-translate-y-1 duration-300">
              <div className="w-16 h-16 rounded-full bg-canteen-red/10 flex items-center justify-center mb-6">
                <ShoppingCart className="h-8 w-8 text-canteen-red" />
              </div>
              <h3 className="text-xl font-bold mb-3">Food Ordering</h3>
              <p className="text-gray-600 mb-4">Browse menu items, add to cart, and place orders with real-time updates.</p>
              <Button 
                variant="link" 
                className="text-canteen-red p-0 flex items-center"
                onClick={() => navigate('/login')}
              >
                Explore menu <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg transition-transform hover:-translate-y-1 duration-300">
              <div className="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mb-6">
                <BookOpenText className="h-8 w-8 text-yellow-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Reviews System</h3>
              <p className="text-gray-600 mb-4">Share your experience and read feedback from other customers.</p>
              <Button 
                variant="link" 
                className="text-yellow-500 p-0 flex items-center"
                onClick={() => navigate('/login')}
              >
                Read reviews <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg transition-transform hover:-translate-y-1 duration-300">
              <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mb-6">
                <MessageCircle className="h-8 w-8 text-green-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">AI-Powered Chatbot</h3>
              <p className="text-gray-600 mb-4">Get instant answers about menu items, ordering process, and more.</p>
              <Button 
                variant="link" 
                className="text-green-500 p-0 flex items-center"
                onClick={() => navigate('/login')}
              >
                Talk to assistant <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-blue-red-gradient text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to get started?</h2>
          <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto">
            Sign in now to experience the future of canteen management with beautiful animations and smart features.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-canteen-blue hover:bg-gray-100 canteen-btn"
            onClick={() => navigate('/login')}
          >
            Sign In Now
          </Button>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h3 className="text-xl font-bold">
                <span className="text-canteen-blue">Canteen</span>
                <span className="text-canteen-red">Hub</span>
              </h3>
              <p className="text-gray-400">Streamlining canteen management</p>
            </div>
            
            <div className="flex flex-wrap justify-center gap-x-8 gap-y-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Features</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Pricing</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">&copy; 2025 CanteenHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
