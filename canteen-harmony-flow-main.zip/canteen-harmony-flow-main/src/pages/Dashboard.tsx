
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Calendar, Plus, ShoppingCart, Star, TrendingUp, User } from 'lucide-react';
import { menuItems } from '@/data/menuData';
import { useCart } from '@/hooks/use-cart';
import FoodCard from '@/components/menu/FoodCard';
import { toast } from 'sonner';
import Layout from '@/components/layout/Layout';

const Dashboard = () => {
  const navigate = useNavigate();
  const { cartItems, addToCart } = useCart();
  const [user, setUser] = useState<{ email: string; isAdmin: boolean } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem('canteen-user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      navigate('/login');
    }
    
    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const handleQuickAdd = (itemId: number) => {
    const item = menuItems.find(item => item.id === itemId);
    if (item) {
      addToCart(item);
      toast.success(`${item.name} added to cart!`);
    }
  };

  const popularItems = menuItems.filter(item => item.isPopular).slice(0, 3);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
            Welcome to <span className="gradient-text">CanteenHub</span>
          </h1>
          <p className="text-gray-600 max-w-3xl animate-fade-in delay-100">
            Your one-stop solution for delicious meals, quick ordering, and seamless canteen management.
          </p>
        </div>
        
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <Card className="canteen-card animate-fade-in delay-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-canteen-blue" />
                Today's Menu
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{menuItems.length}</p>
              <p className="text-gray-500 text-sm">Available items</p>
              
              <Button 
                variant="link" 
                className="p-0 mt-4 text-canteen-blue"
                onClick={() => navigate('/menu')}
              >
                View Menu <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <ShoppingCart className="mr-2 h-5 w-5 text-canteen-red" />
                Your Cart
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{cartItems.length}</p>
              <p className="text-gray-500 text-sm">Items in cart</p>
              
              <Button 
                variant="link" 
                className="p-0 mt-4 text-canteen-red"
                onClick={() => navigate('/cart')}
              >
                View Cart <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-400">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Star className="mr-2 h-5 w-5 text-yellow-500" />
                Top Rated
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">4.8</p>
              <p className="text-gray-500 text-sm">Average rating</p>
              
              <Button 
                variant="link" 
                className="p-0 mt-4 text-yellow-500"
                onClick={() => navigate('/reviews')}
              >
                See Reviews <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
        
        {/* Popular Items Section */}
        <div className="mb-10">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-canteen-red" />
              Popular Items
            </h2>
            <Button 
              variant="outline" 
              onClick={() => navigate('/menu')}
              className="border-canteen-blue text-canteen-blue hover:bg-canteen-blue hover:text-white"
            >
              View All Menu
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {popularItems.map((item, index) => (
              <div key={item.id} className="animate-fade-in" style={{ animationDelay: `${(index + 5) * 100}ms` }}>
                <FoodCard item={item} />
              </div>
            ))}
          </div>
        </div>
        
        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="canteen-card animate-fade-in delay-800">
            <CardHeader>
              <CardTitle>Need assistance?</CardTitle>
              <CardDescription>
                Our chatbot is available 24/7 to answer your questions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="canteen-btn-primary w-full"
                onClick={() => navigate('/chatbot')}
              >
                Chat with Assistant
              </Button>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-900">
            <CardHeader>
              <CardTitle>Share your feedback</CardTitle>
              <CardDescription>
                Help us improve by sharing your experience.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="canteen-btn-secondary w-full"
                onClick={() => navigate('/reviews')}
              >
                Write a Review
              </Button>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-1000">
            <CardHeader>
              <CardTitle>Your Profile</CardTitle>
              <CardDescription>
                Manage your account and preferences.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full border-canteen-blue text-canteen-blue hover:bg-canteen-blue hover:text-white"
                onClick={() => navigate('/profile')}
              >
                View Profile
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
