
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Package } from 'lucide-react';
import { menuItems, categories } from '@/data/menuData';
import FoodCard, { FoodItem } from '@/components/menu/FoodCard';
import Layout from '@/components/layout/Layout';

const Menu = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [filteredItems, setFilteredItems] = useState<FoodItem[]>(menuItems);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const user = localStorage.getItem('canteen-user');
    if (!user) {
      navigate('/login');
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  useEffect(() => {
    filterItems();
  }, [searchTerm, selectedCategory]);

  const filterItems = () => {
    let filtered = menuItems;

    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        item => 
          item.name.toLowerCase().includes(term) || 
          item.description.toLowerCase().includes(term)
      );
    }

    setFilteredItems(filtered);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-2">
          <h1 className="text-3xl md:text-4xl font-bold animate-fade-in">
            Our <span className="gradient-text">Menu</span>
          </h1>
          <Button
            onClick={() => navigate('/orders-inventory')}
            className="flex items-center gap-2 bg-canteen-blue hover:bg-canteen-blue-dark text-white transition-all duration-300 animate-fade-in"
          >
            <Package className="w-5 h-5" />
            Track Orders & Supplies
          </Button>
        </div>

        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Explore our delicious options and place your order with just a few clicks.
        </p>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4 animate-fade-in delay-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="search"
              placeholder="Search menu items..."
              className="pl-10 canteen-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                className={
                  selectedCategory === category 
                    ? 'bg-canteen-blue hover:bg-canteen-blue-dark' 
                    : 'border-canteen-blue text-canteen-blue hover:bg-canteen-blue/10'
                }
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Menu Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-12 animate-fade-in">
            <h3 className="text-xl font-medium text-gray-600">No items found</h3>
            <p className="text-gray-500 mt-2">Try a different search or category</p>
            <Button 
              className="mt-4 canteen-btn-primary" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All');
              }}
            >
              Clear Filters
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item, index) => (
              <div key={item.id} className="animate-fade-in" style={{animationDelay: `${(index + 3) * 100}ms`}}>
                <FoodCard item={item} />
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Menu;
