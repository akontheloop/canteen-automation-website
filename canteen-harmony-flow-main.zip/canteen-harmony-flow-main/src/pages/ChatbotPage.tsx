
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import Chatbot from '@/components/chatbot/Chatbot';

const ChatbotPage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const user = localStorage.getItem('canteen-user');
    if (!user) {
      navigate('/login');
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Canteen <span className="gradient-text">Assistant</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Ask any questions about our canteen services, menu, or ordering process.
        </p>

        {/* Full page chatbot */}
        <div className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden animate-fade-in delay-200">
          <div className="bg-canteen-blue text-white p-4">
            <h2 className="text-lg font-semibold">Chat with our CanteenHub Assistant</h2>
            <p className="text-sm opacity-80">Get instant answers to all your canteen-related questions</p>
          </div>
          
          <div className="h-[500px] overflow-y-auto p-4 bg-gray-50">
            {/* Chatbot component - it already has all the chat UI */}
            <Chatbot />
          </div>
        </div>

        <div className="mt-8 max-w-4xl mx-auto animate-fade-in delay-400">
          <h3 className="text-xl font-semibold mb-4">Frequently Asked Questions</h3>
          
          <div className="space-y-4">
            <div className="p-4 border rounded-lg bg-white shadow-sm">
              <h4 className="font-medium text-canteen-blue mb-1">What are today's specials?</h4>
              <p className="text-gray-600">Ask about the day's special menu items and promotions.</p>
            </div>
            
            <div className="p-4 border rounded-lg bg-white shadow-sm">
              <h4 className="font-medium text-canteen-blue mb-1">How do I place an order?</h4>
              <p className="text-gray-600">Get help with the ordering process and payment methods.</p>
            </div>
            
            <div className="p-4 border rounded-lg bg-white shadow-sm">
              <h4 className="font-medium text-canteen-blue mb-1">Do you have vegetarian options?</h4>
              <p className="text-gray-600">Learn about our dietary accommodations and special menus.</p>
            </div>
            
            <div className="p-4 border rounded-lg bg-white shadow-sm">
              <h4 className="font-medium text-canteen-blue mb-1">What are the canteen hours?</h4>
              <p className="text-gray-600">Find out when our canteen services are available.</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ChatbotPage;
