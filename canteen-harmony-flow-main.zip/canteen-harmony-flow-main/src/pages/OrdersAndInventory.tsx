
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Package, Truck, List, Warehouse } from 'lucide-react';
import { toast } from 'sonner';

interface Order {
  id: number;
  items: { name: string; quantity: number }[];
  status: 'processing' | 'shipped' | 'delivered';
  trackingNumber: string;
  estimatedDelivery: string;
  progress: number;
}

interface SupplyItem {
  id: number;
  name: string;
  currentStock: number;
  minRequired: number;
  unit: string;
  status: 'good' | 'low' | 'critical';
}

const mockOrders: Order[] = [
  {
    id: 1,
    items: [{ name: 'Fresh Vegetables', quantity: 50 }, { name: 'Rice', quantity: 25 }],
    status: 'processing',
    trackingNumber: 'TRK123456789',
    estimatedDelivery: '2025-04-30',
    progress: 25
  },
  {
    id: 2,
    items: [{ name: 'Cooking Oil', quantity: 30 }, { name: 'Spices', quantity: 40 }],
    status: 'shipped',
    trackingNumber: 'TRK987654321',
    estimatedDelivery: '2025-04-29',
    progress: 75
  }
];

const mockSupplies: SupplyItem[] = [
  { id: 1, name: 'Rice', currentStock: 100, minRequired: 50, unit: 'kg', status: 'good' },
  { id: 2, name: 'Cooking Oil', currentStock: 15, minRequired: 20, unit: 'L', status: 'low' },
  { id: 3, name: 'Fresh Vegetables', currentStock: 5, minRequired: 30, unit: 'kg', status: 'critical' }
];

const OrdersAndInventory = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [supplies, setSupplies] = useState<SupplyItem[]>(mockSupplies);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const user = localStorage.getItem('canteen-user');
    if (!user) {
      navigate('/login');
      return;
    }

    // Load data from localStorage or use mock data
    const savedOrders = localStorage.getItem('canteen-orders');
    if (savedOrders) {
      try {
        setOrders(JSON.parse(savedOrders));
      } catch (e) {
        console.error('Failed to parse orders data', e);
      }
    }

    const savedSupplies = localStorage.getItem('canteen-supplies');
    if (savedSupplies) {
      try {
        setSupplies(JSON.parse(savedSupplies));
      } catch (e) {
        console.error('Failed to parse supplies data', e);
      }
    }

    setTimeout(() => setIsLoading(false), 500);
  }, [navigate]);

  useEffect(() => {
    localStorage.setItem('canteen-orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('canteen-supplies', JSON.stringify(supplies));
  }, [supplies]);

  const getStatusColor = (status: SupplyItem['status']) => {
    switch (status) {
      case 'good':
        return 'text-green-500';
      case 'low':
        return 'text-yellow-500';
      case 'critical':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  const requestSupplyRestock = (itemId: number) => {
    toast.success(`Restock request sent for item #${itemId}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Orders & <span className="gradient-text">Inventory</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Track your orders and manage inventory levels
        </p>

        <Tabs defaultValue="orders" className="animate-fade-in delay-200">
          <TabsList className="mb-6">
            <TabsTrigger value="orders">Active Orders</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <div className="grid gap-6">
              {orders.map((order) => (
                <Card key={order.id} className="canteen-card hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Truck className="mr-2 h-5 w-5 text-canteen-blue" />
                        Order #{order.id}
                      </div>
                      <span className={`text-sm px-3 py-1 rounded-full ${
                        order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                        order.status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Items:</p>
                        <div className="space-y-1">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex justify-between text-sm">
                              <span>{item.name}</span>
                              <span>x{item.quantity}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Tracking Number:</p>
                        <p className="font-mono">{order.trackingNumber}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Estimated Delivery:</p>
                        <p>{new Date(order.estimatedDelivery).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Progress:</p>
                        <Progress value={order.progress} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="inventory">
            <Card className="canteen-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Warehouse className="mr-2 h-5 w-5 text-canteen-blue" />
                  Current Inventory
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Name</TableHead>
                      <TableHead>Current Stock</TableHead>
                      <TableHead>Min. Required</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {supplies.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>
                          {item.currentStock} {item.unit}
                        </TableCell>
                        <TableCell>
                          {item.minRequired} {item.unit}
                        </TableCell>
                        <TableCell>
                          <span className={`font-medium ${getStatusColor(item.status)}`}>
                            {item.status.toUpperCase()}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            onClick={() => requestSupplyRestock(item.id)}
                            className={`${
                              item.status === 'critical' 
                                ? 'border-red-500 text-red-500 hover:bg-red-50'
                                : item.status === 'low'
                                ? 'border-yellow-500 text-yellow-500 hover:bg-yellow-50'
                                : 'border-green-500 text-green-500 hover:bg-green-50'
                            }`}
                          >
                            Request Restock
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default OrdersAndInventory;
