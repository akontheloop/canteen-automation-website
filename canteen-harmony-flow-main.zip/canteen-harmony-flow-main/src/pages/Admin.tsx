
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, Clipboard, Settings, ShoppingBag, Users } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '@/components/layout/Layout';
import { menuItems } from '@/data/menuData';

interface Order {
  id: number;
  customerName: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: 'pending' | 'preparing' | 'ready' | 'completed';
  timestamp: string;
}

// Sample orders data for demonstration
const mockOrders: Order[] = [
  {
    id: 1001,
    customerName: 'John Doe',
    items: [
      { name: 'Classic Burger', quantity: 2, price: 8.99 },
      { name: 'Caesar Salad', quantity: 1, price: 6.99 }
    ],
    total: 24.97,
    status: 'pending',
    timestamp: '2025-04-27T09:30:00'
  },
  {
    id: 1002,
    customerName: 'Emily Wilson',
    items: [
      { name: 'Margherita Pizza', quantity: 1, price: 10.99 },
      { name: 'Chocolate Brownie', quantity: 2, price: 4.99 }
    ],
    total: 20.97,
    status: 'preparing',
    timestamp: '2025-04-27T10:15:00'
  },
  {
    id: 1003,
    customerName: 'Michael Brown',
    items: [
      { name: 'Pasta Alfredo', quantity: 1, price: 9.99 },
      { name: 'Fruit Smoothie', quantity: 1, price: 4.49 }
    ],
    total: 14.48,
    status: 'ready',
    timestamp: '2025-04-27T08:45:00'
  },
  {
    id: 1004,
    customerName: 'Sarah Johnson',
    items: [
      { name: 'Vegetable Stir-Fry', quantity: 1, price: 8.49 },
      { name: 'Grilled Chicken Wrap', quantity: 1, price: 7.99 }
    ],
    total: 16.48,
    status: 'completed',
    timestamp: '2025-04-26T15:20:00'
  }
];

const Admin = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<{ email: string; isAdmin: boolean } | null>(null);
  const [orders, setOrders] = useState<Order[]>(mockOrders);

  useEffect(() => {
    // Check if user is logged in and is admin
    const storedUser = localStorage.getItem('canteen-user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
      
      if (!parsedUser.isAdmin) {
        toast.error('You do not have admin access');
        navigate('/dashboard');
      }
    } else {
      navigate('/login');
    }

    // Load orders from localStorage or use mock data
    const savedOrders = localStorage.getItem('canteen-admin-orders');
    if (savedOrders) {
      try {
        setOrders(JSON.parse(savedOrders));
      } catch (e) {
        console.error('Failed to parse orders data', e);
      }
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  useEffect(() => {
    // Save orders to localStorage when they change
    localStorage.setItem('canteen-admin-orders', JSON.stringify(orders));
  }, [orders]);

  const updateOrderStatus = (orderId: number, newStatus: Order['status']) => {
    setOrders(prevOrders =>
      prevOrders.map(order =>
        order.id === orderId ? { ...order, status: newStatus } : order
      )
    );
    
    toast.success(`Order #${orderId} status updated to ${newStatus}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Admin <span className="gradient-text">Dashboard</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          Manage orders, inventory, and system settings.
        </p>

        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="canteen-card animate-fade-in delay-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <ShoppingBag className="mr-2 h-5 w-5 text-canteen-blue" />
                Total Orders
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{orders.length}</p>
              <p className="text-gray-500 text-sm">Active orders</p>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-300">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Users className="mr-2 h-5 w-5 text-canteen-red" />
                Customers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">24</p>
              <p className="text-gray-500 text-sm">Active today</p>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-400">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <Clipboard className="mr-2 h-5 w-5 text-yellow-500" />
                Menu Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{menuItems.length}</p>
              <p className="text-gray-500 text-sm">Available items</p>
            </CardContent>
          </Card>
          
          <Card className="canteen-card animate-fade-in delay-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center">
                <BarChart className="mr-2 h-5 w-5 text-green-500" />
                Revenue
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">$738</p>
              <p className="text-gray-500 text-sm">Today</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="orders" className="animate-fade-in delay-600">
          <TabsList className="mb-6">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <Card className="canteen-card">
              <CardHeader>
                <CardTitle>Manage Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b text-left">
                        <th className="p-3">Order ID</th>
                        <th className="p-3">Customer</th>
                        <th className="p-3">Items</th>
                        <th className="p-3">Total</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Time</th>
                        <th className="p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => (
                        <tr key={order.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">#{order.id}</td>
                          <td className="p-3">{order.customerName}</td>
                          <td className="p-3">
                            <div className="text-sm">
                              {order.items.map((item, idx) => (
                                <div key={idx}>
                                  {item.quantity}x {item.name}
                                </div>
                              ))}
                            </div>
                          </td>
                          <td className="p-3">${order.total.toFixed(2)}</td>
                          <td className="p-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              order.status === 'pending' 
                                ? 'bg-yellow-100 text-yellow-800' 
                                : order.status === 'preparing' 
                                ? 'bg-blue-100 text-blue-800' 
                                : order.status === 'ready' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                          </td>
                          <td className="p-3 text-sm">
                            {new Date(order.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </td>
                          <td className="p-3">
                            <div className="flex space-x-2">
                              {order.status === 'pending' && (
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="text-blue-500 border-blue-500 hover:bg-blue-50"
                                  onClick={() => updateOrderStatus(order.id, 'preparing')}
                                >
                                  Prepare
                                </Button>
                              )}
                              
                              {order.status === 'preparing' && (
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="text-green-500 border-green-500 hover:bg-green-50"
                                  onClick={() => updateOrderStatus(order.id, 'ready')}
                                >
                                  Ready
                                </Button>
                              )}
                              
                              {order.status === 'ready' && (
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="text-gray-500 border-gray-500 hover:bg-gray-50"
                                  onClick={() => updateOrderStatus(order.id, 'completed')}
                                >
                                  Complete
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory">
            <Card className="canteen-card">
              <CardHeader>
                <CardTitle>Manage Inventory</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b text-left">
                        <th className="p-3">Item ID</th>
                        <th className="p-3">Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Price</th>
                        <th className="p-3">Popular</th>
                        <th className="p-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {menuItems.map((item) => (
                        <tr key={item.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 font-medium">#{item.id}</td>
                          <td className="p-3">{item.name}</td>
                          <td className="p-3">{item.category}</td>
                          <td className="p-3">${item.price.toFixed(2)}</td>
                          <td className="p-3">
                            {item.isPopular ? (
                              <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Yes
                              </span>
                            ) : (
                              <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                No
                              </span>
                            )}
                          </td>
                          <td className="p-3">
                            <div className="flex space-x-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="text-canteen-blue border-canteen-blue hover:bg-canteen-blue/10"
                                onClick={() => toast.info('Edit functionality coming soon')}
                              >
                                Edit
                              </Button>
                              
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="text-canteen-red border-canteen-red hover:bg-canteen-red/10"
                                onClick={() => toast.info('Delete functionality coming soon')}
                              >
                                Delete
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card className="canteen-card">
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Settings className="mx-auto h-16 w-16 text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium text-gray-600 mb-2">User Management</h3>
                  <p className="text-gray-500 mb-4 max-w-md mx-auto">
                    This feature is currently under development. Soon you'll be able to manage users, 
                    roles, and permissions.
                  </p>
                  <Button 
                    className="canteen-btn-primary"
                    onClick={() => toast.info('Feature coming soon!')}
                  >
                    Notify Me When Ready
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="canteen-card">
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Settings className="mx-auto h-16 w-16 text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium text-gray-600 mb-2">System Settings</h3>
                  <p className="text-gray-500 mb-4 max-w-md mx-auto">
                    This feature is currently under development. Soon you'll be able to configure 
                    system settings, notification preferences, and more.
                  </p>
                  <Button 
                    className="canteen-btn-primary"
                    onClick={() => toast.info('Feature coming soon!')}
                  >
                    Notify Me When Ready
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Admin;
