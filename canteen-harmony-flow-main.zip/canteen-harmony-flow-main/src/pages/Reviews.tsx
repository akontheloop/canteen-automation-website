import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star } from 'lucide-react';
import { reviewsData, Review } from '@/data/reviewsData';
import ReviewForm from '@/components/reviews/ReviewForm';
import Layout from '@/components/layout/Layout';

const Reviews = () => {
  const navigate = useNavigate();
  const [reviews, setReviews] = useState<Review[]>(reviewsData);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const user = localStorage.getItem('canteen-user');
    if (!user) {
      navigate('/login');
    }

    const savedReviews = localStorage.getItem('canteen-reviews');
    if (savedReviews) {
      try {
        setReviews(JSON.parse(savedReviews));
      } catch (e) {
        console.error('Failed to parse reviews data', e);
      }
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  }, [navigate]);

  useEffect(() => {
    localStorage.setItem('canteen-reviews', JSON.stringify(reviews));
  }, [reviews]);

  const handleReviewSubmit = (newReview: {name: string; rating: number; comment: string;}) => {
    const review: Review = {
      id: reviews.length + 1,
      name: newReview.name,
      rating: newReview.rating,
      date: new Date().toISOString().split('T')[0],
      comment: newReview.comment,
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${newReview.name}`,
    };
    
    setReviews([review, ...reviews]);
  };

  const getRatingStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star 
        key={index} 
        className={`w-4 h-4 ${index < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
      />
    ));
  };

  const getAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((total, review) => total + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-10 h-10 border-4 border-canteen-blue border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 animate-fade-in">
          Customer <span className="gradient-text">Reviews</span>
        </h1>
        <p className="text-gray-600 mb-8 animate-fade-in delay-100">
          See what others are saying about our canteen services and share your experience.
        </p>

        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/3 animate-fade-in delay-200">
            <Card className="canteen-card p-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-2">Overall Rating</h2>
                <div className="text-5xl font-bold text-canteen-blue mb-2">
                  {getAverageRating()}
                </div>
                <div className="flex justify-center mb-4">
                  {getRatingStars(Math.round(Number(getAverageRating())))}
                </div>
                <p className="text-gray-500">Based on {reviews.length} reviews</p>
              </div>
            </Card>

            <div className="mt-8">
              <ReviewForm onReviewSubmit={handleReviewSubmit} />
            </div>
          </div>

          <div className="w-full md:w-2/3 animate-fade-in delay-300">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="all">All Reviews</TabsTrigger>
                <TabsTrigger value="positive">Positive</TabsTrigger>
                <TabsTrigger value="negative">Critical</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4">
                {reviews.map((review, index) => (
                  <Card key={review.id} className="canteen-card p-4 animate-fade-in" style={{animationDelay: `${(index + 4) * 100}ms`}}>
                    <CardContent className="p-0">
                      <div className="flex items-start">
                        <Avatar className="h-10 w-10 mr-4">
                          <AvatarImage src={review.avatar} alt={review.name} />
                          <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex justify-between items-center mb-1">
                            <h3 className="font-semibold">{review.name}</h3>
                            <span className="text-gray-500 text-sm">{review.date}</span>
                          </div>
                          <div className="flex mb-2">
                            {getRatingStars(review.rating)}
                          </div>
                          <p className="text-gray-700">{review.comment}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="positive" className="space-y-4">
                {reviews
                  .filter(review => review.rating >= 4)
                  .map((review, index) => (
                    <Card key={review.id} className="canteen-card p-4 animate-fade-in" style={{animationDelay: `${(index + 4) * 100}ms`}}>
                      <CardContent className="p-0">
                        <div className="flex items-start">
                          <Avatar className="h-10 w-10 mr-4">
                            <AvatarImage src={review.avatar} alt={review.name} />
                            <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-center mb-1">
                              <h3 className="font-semibold">{review.name}</h3>
                              <span className="text-gray-500 text-sm">{review.date}</span>
                            </div>
                            <div className="flex mb-2">
                              {getRatingStars(review.rating)}
                            </div>
                            <p className="text-gray-700">{review.comment}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>

              <TabsContent value="negative" className="space-y-4">
                {reviews
                  .filter(review => review.rating < 4)
                  .map((review, index) => (
                    <Card key={review.id} className="canteen-card p-4 animate-fade-in" style={{animationDelay: `${(index + 4) * 100}ms`}}>
                      <CardContent className="p-0">
                        <div className="flex items-start">
                          <Avatar className="h-10 w-10 mr-4">
                            <AvatarImage src={review.avatar} alt={review.name} />
                            <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-center mb-1">
                              <h3 className="font-semibold">{review.name}</h3>
                              <span className="text-gray-500 text-sm">{review.date}</span>
                            </div>
                            <div className="flex mb-2">
                              {getRatingStars(review.rating)}
                            </div>
                            <p className="text-gray-700">{review.comment}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Reviews;
