
import { createClient } from '@supabase/supabase-js';

// Check for environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Log error when environment variables are missing
if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    "Supabase URL and/or Anonymous Key missing. Make sure to set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables."
  );
}

// Create a Supabase client with either real credentials or placeholder values
// The createClient requires valid URL format strings, even if they're not real Supabase URLs
export const supabase = createClient(
  supabaseUrl || 'https://example.com', 
  supabaseAnonKey || 'invalid-key'
);
