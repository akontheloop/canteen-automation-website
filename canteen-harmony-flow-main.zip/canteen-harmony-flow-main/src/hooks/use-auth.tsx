
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { User } from '@supabase/supabase-js';
import { toast } from 'sonner';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signOut: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  isSupabaseConfigured: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  // Check if Supabase is configured properly
  const isSupabaseConfigured = Boolean(
    import.meta.env.VITE_SUPABASE_URL && 
    import.meta.env.VITE_SUPABASE_ANON_KEY
  );

  useEffect(() => {
    // If Supabase isn't configured, use local storage fallback
    if (!isSupabaseConfigured) {
      const storedUser = localStorage.getItem('canteen-user');
      if (storedUser) {
        try {
          const parsedUser = JSON.parse(storedUser);
          // Create a simplified user object that matches what components expect
          setUser({
            id: parsedUser.email,
            email: parsedUser.email,
            app_metadata: {},
            user_metadata: {
              isAdmin: parsedUser.isAdmin
            },
            aud: 'authenticated',
            created_at: '',
          } as unknown as User);
        } catch (error) {
          console.error('Failed to parse user from localStorage', error);
        }
      }
      setLoading(false);
      return;
    }

    // Check active sessions and sets the user
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Listen for changes on auth state
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription?.unsubscribe();
  }, [isSupabaseConfigured]);

  const signIn = async (email: string, password: string) => {
    if (!isSupabaseConfigured) {
      // Fallback mock auth for development
      const mockUser = {
        email,
        isAdmin: email.includes('admin'),
      };
      
      localStorage.setItem('canteen-user', JSON.stringify(mockUser));
      
      // Create a simplified user object
      setUser({
        id: email,
        email: email,
        app_metadata: {},
        user_metadata: {
          isAdmin: mockUser.isAdmin
        },
        aud: 'authenticated',
        created_at: '',
      } as unknown as User);
      
      toast.success('Login successful!');
      navigate('/dashboard');
      return;
    }
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast.error(error.message);
      throw error;
    }
    
    toast.success('Login successful!');
    navigate('/dashboard');
  };

  const signOut = async () => {
    if (!isSupabaseConfigured) {
      localStorage.removeItem('canteen-user');
      setUser(null);
      navigate('/login');
      return;
    }
    
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, loading, signOut, signIn, isSupabaseConfigured }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
