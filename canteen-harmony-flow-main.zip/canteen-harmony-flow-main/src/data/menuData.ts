
export const menuItems = [
  {
    id: 1,
    name: "Classic Burger",
    description: "Juicy beef patty with lettuce, tomato, cheese, and our signature sauce on a toasted brioche bun.",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=2089&auto=format&fit=crop",
    category: "Main Course",
    isPopular: true
  },
  {
    id: 2,
    name: "Caesar Salad",
    description: "Crisp romaine lettuce, parmesan cheese, croutons, and Caesar dressing. Add chicken for extra protein.",
    price: 6.99,
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?q=80&w=2070&auto=format&fit=crop",
    category: "Salads",
    isPopular: false
  },
  {
    id: 3,
    name: "Margherita Pizza",
    description: "Traditional pizza with tomato sauce, fresh mozzarella, basil, and olive oil.",
    price: 10.99,
    image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?q=80&w=2070&auto=format&fit=crop",
    category: "Main Course",
    isPopular: true
  },
  {
    id: 4,
    name: "Grilled Chicken Wrap",
    description: "Tender grilled chicken, mixed greens, tomatoes, and ranch dressing wrapped in a spinach tortilla.",
    price: 7.99,
    image: "https://images.unsplash.com/photo-1562967914-608f82629710?q=80&w=2073&auto=format&fit=crop",
    category: "Sandwiches & Wraps",
    isPopular: false
  },
  {
    id: 5,
    name: "Pasta Alfredo",
    description: "Fettuccine pasta in a creamy Alfredo sauce with parmesan cheese and parsley.",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1645112411341-6c4fd023882a?q=80&w=2070&auto=format&fit=crop",
    category: "Main Course",
    isPopular: false
  },
  {
    id: 6,
    name: "Chocolate Brownie",
    description: "Rich, fudgy chocolate brownie served warm with vanilla ice cream.",
    price: 4.99,
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?q=80&w=2070&auto=format&fit=crop",
    category: "Desserts",
    isPopular: true
  },
  {
    id: 7,
    name: "Vegetable Stir-Fry",
    description: "Assorted fresh vegetables stir-fried in a savory sauce, served with steamed rice.",
    price: 8.49,
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=2070&auto=format&fit=crop",
    category: "Vegetarian",
    isPopular: false
  },
  {
    id: 8,
    name: "Fruit Smoothie",
    description: "Blend of fresh fruits with yogurt and honey for a refreshing healthy drink.",
    price: 4.49,
    image: "https://images.unsplash.com/photo-1589733955941-5eeaf752f6dd?q=80&w=1973&auto=format&fit=crop",
    category: "Beverages",
    isPopular: false
  }
];

export const categories = [
  "All",
  "Main Course",
  "Salads",
  "Sandwiches & Wraps",
  "Vegetarian",
  "Desserts",
  "Beverages"
];
