
export interface Review {
  id: number;
  name: string;
  rating: number;
  date: string;
  comment: string;
  avatar?: string;
}

export const reviewsData: Review[] = [
  {
    id: 1,
    name: "Jane Smith",
    rating: 5,
    date: "2025-03-15",
    comment: "The food quality is excellent! I particularly love the salad bar and daily specials. The staff is always friendly and helpful.",
    avatar: "https://randomuser.me/api/portraits/women/1.jpg"
  },
  {
    id: 2,
    name: "John Doe",
    rating: 4,
    date: "2025-03-10",
    comment: "Great variety of options every day. The ordering system is smooth and convenient. Would recommend the pasta dishes!",
    avatar: "https://randomuser.me/api/portraits/men/1.jpg"
  },
  {
    id: 3,
    name: "Sarah Johnson",
    rating: 5,
    date: "2025-03-05",
    comment: "I appreciate the vegetarian options available. Everything is always fresh and delicious. The mobile ordering feature saves me so much time!",
    avatar: "https://randomuser.me/api/portraits/women/2.jpg"
  },
  {
    id: 4,
    name: "Michael Brown",
    rating: 3,
    date: "2025-02-28",
    comment: "Food is good but sometimes the wait is too long during peak hours. Would love to see more quick grab-and-go options.",
    avatar: "https://randomuser.me/api/portraits/men/2.jpg"
  },
  {
    id: 5,
    name: "Emily Wilson",
    rating: 5,
    date: "2025-02-20",
    comment: "The new menu items are fantastic! I'm impressed with how the canteen keeps innovating while maintaining quality. The desserts are to die for!",
    avatar: "https://randomuser.me/api/portraits/women/3.jpg"
  }
];
